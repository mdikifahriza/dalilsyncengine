// src/hooks/useFixedSchedules.ts
import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { fixedScheduleService } from '@/services/fixedScheduleService';
import type {
  FixedScheduleWithRelations,
  CreateFixedScheduleInput,
  UpdateFixedScheduleInput,
} from '@/types/database.types';

export function useFixedSchedules(kelasId?: number) {
  const { user } = useAuth();
  const [fixedSchedules, setFixedSchedules] = useState<FixedScheduleWithRelations[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchFixedSchedules = useCallback(async () => {
    if (!user) return;
    if (kelasId === undefined) return;

    setLoading(true);
    setError(null);

    try {
      const data = await fixedScheduleService.getByKelas(kelasId);
      setFixedSchedules(data);
    } catch (err: any) {
      console.error('Error fetching fixed schedules:', err);
      setError(err.message || 'Gagal memuat jadwal tetap');
    } finally {
      setLoading(false);
    }
  }, [user, kelasId]);

  useEffect(() => {
    fetchFixedSchedules();
  }, [fetchFixedSchedules]);

  const createFixedSchedule = async (input: CreateFixedScheduleInput) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const newSchedule = await fixedScheduleService.create(user.id, input);
      setFixedSchedules((prev) => [...prev, newSchedule as FixedScheduleWithRelations]);
      return newSchedule;
    } catch (err: any) {
      console.error('Error creating fixed schedule:', err);
      throw new Error(err.message || 'Gagal membuat jadwal tetap');
    }
  };

  const updateFixedSchedule = async (id: number, input: UpdateFixedScheduleInput) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const updated = await fixedScheduleService.update(id, user.id, input);
      setFixedSchedules((prev) =>
        prev.map((s) =>
          s.id === id ? { ...s, ...updated } : s
        )
      );
      return updated;
    } catch (err: any) {
      console.error('Error updating fixed schedule:', err);
      throw new Error(err.message || 'Gagal mengupdate jadwal tetap');
    }
  };

  const deleteFixedSchedule = async (id: number) => {
    if (!user) throw new Error('User not authenticated');

    try {
      await fixedScheduleService.delete(id, user.id);
      setFixedSchedules((prev) => prev.filter((s) => s.id !== id));
    } catch (err: any) {
      console.error('Error deleting fixed schedule:', err);
      throw new Error(err.message || 'Gagal menghapus jadwal tetap');
    }
  };

  const deleteByKelas = async (kelasId: number) => {
    if (!user) throw new Error('User not authenticated');

    try {
      await fixedScheduleService.deleteByKelas(kelasId, user.id);
      setFixedSchedules([]);
    } catch (err: any) {
      console.error('Error deleting fixed schedules by class:', err);
      throw new Error(err.message || 'Gagal menghapus jadwal tetap kelas');
    }
  };

  const isSlotUsed = async (
    kelasId: number,
    timeBlockId: number,
    hari: string,
    excludeId?: number
  ): Promise<boolean> => {
    try {
      return await fixedScheduleService.isSlotUsed(kelasId, timeBlockId, hari, excludeId);
    } catch (err: any) {
      console.error('Error checking slot:', err);
      return false;
    }
  };

  const getCountByKelas = async (kelasId: number): Promise<number> => {
    try {
      return await fixedScheduleService.getCountByKelas(kelasId);
    } catch (err: any) {
      console.error('Error getting count:', err);
      return 0;
    }
  };

  return {
    fixedSchedules,
    loading,
    error,
    fetchFixedSchedules,
    createFixedSchedule,
    updateFixedSchedule,
    deleteFixedSchedule,
    deleteByKelas,
    isSlotUsed,
    getCountByKelas,
  };
}