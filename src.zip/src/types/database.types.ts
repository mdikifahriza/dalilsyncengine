// src/types/database.types.ts - UPDATED VERSION
// CHANGES:
// - Added is_non_jp to TimeBlock
// - Added hari_aktif to ClassGroup
// - Added FixedSchedule interface
// - Updated CreateTimeBlockInput

export type Jenjang = 'TK' | 'PAUD' | 'SD' | 'MI' | 'SMP' | 'MTs' | 'SMA' | 'MA' | 'SMK';
export type ModelSekolah = 'Reguler' | 'Boarding' | 'Mandiri' | 'Internasional';
export type TipeBlock = 'lesson' | 'break' | 'prayer' | 'event';
export type Prioritas = 1 | 2 | 3;

// =====================================================
// CORE TYPES
// =====================================================

export interface SchoolProfile {
  id: number;
  user_id: string;
  nama_sekolah: string;
  jenjang: Jenjang;
  model_sekolah?: ModelSekolah;
  zona_waktu: string;
  logo_url?: string;
  created_at: string;
  updated_at: string;
}

export interface TimeBlock {
  id: number;
  user_id: string;
  nama_block: string;
  tipe_block: TipeBlock;
  jam_mulai: string;
  jam_selesai: string;
  urutan: number;
  hari_berlaku?: string[] | null;
  warna: string;
  is_fixed: boolean; // Deprecated: use is_non_jp instead
  is_non_jp: boolean; // NEW: true if not counted as JP
  created_at: string;
}

export interface TimeBlockKelas {
  id: number;
  kelas_id: number;
  time_block_id: number;
  hari?: string | null;
  created_at: string;
}

export interface MapelKelas {
  id: number;
  user_id: string;
  kelas_id: number;
  mapel_id: number;
  guru_id?: number;
  jumlah_jam_per_minggu: number;
  created_at: string;
  updated_at: string;
}

export interface ScheduleTemplate {
  id: number;
  user_id: string;
  nama_template: string;
  jenjang: Jenjang;
  deskripsi?: string;
  time_blocks?: any;
  constraints?: any;
  is_public: boolean;
  created_at: string;
  updated_at: string;
}

// NEW: Fixed Schedule
export interface FixedSchedule {
  id: number;
  user_id: string;
  kelas_id: number;
  mapel_kelas_id: number;
  time_block_id: number;
  hari: string;
  is_locked: boolean;
  created_at: string;
  updated_at: string;
}

// =====================================================
// MAIN ENTITY TYPES
// =====================================================

export interface Teacher {
  id: number;
  user_id: string;
  nama: string;
  jam_maks: number;
  hari_tidak_bisa?: string;
  created_at: string;
  updated_at: string;
}

export interface Subject {
  id: number;
  user_id: string;
  nama_mapel: string;
  created_at: string;
  updated_at: string;
}

export interface ClassGroup {
  id: number;
  user_id: string;
  nama_kelas: string;
  tingkat?: number;
  jam_mulai?: string;
  jam_selesai?: string;
  hari_operasional?: string[];
  hari_aktif?: string[]; // NEW: Active days for GA generation
  wali_kelas?: string;
  jumlah_siswa?: number;
  created_at: string;
  updated_at: string;
}

export interface ScheduleSlot {
  id: number;
  ga_run_id: number;
  kelas_id: number;
  guru_id: number;
  mapel_id: number;
  hari: string;
  jam_ke?: number;
  time_block_id?: number;
  ruang_nama?: string;
  keterangan?: string;
  created_at: string;
}

// =====================================================
// WITH RELATIONS
// =====================================================

export interface TimeBlockWithRelations extends TimeBlock {
  slot_count?: number;
}

export interface TimeBlockKelasWithRelations extends TimeBlockKelas {
  kelas?: ClassGroup;
  time_block?: TimeBlock;
}

export interface MapelKelasWithRelations extends MapelKelas {
  kelas?: ClassGroup;
  mapel?: Subject;
  guru?: Teacher;
}

export interface FixedScheduleWithRelations extends FixedSchedule {
  kelas?: ClassGroup;
  mapel_kelas?: MapelKelasWithRelations;
  time_block?: TimeBlock;
}

export interface ScheduleSlotWithDetails extends ScheduleSlot {
  kelas: ClassGroup;
  guru: Teacher;
  mapel: Subject;
  time_block?: TimeBlock;
}

// =====================================================
// INPUT TYPES
// =====================================================

export interface CreateSchoolProfileInput {
  nama_sekolah: string;
  jenjang: Jenjang;
  model_sekolah?: ModelSekolah;
  zona_waktu?: string;
  logo_url?: string;
}

export interface UpdateSchoolProfileInput extends Partial<CreateSchoolProfileInput> {}

export interface CreateTimeBlockInput {
  nama_block: string;
  tipe_block: TipeBlock;
  jam_mulai: string;
  jam_selesai: string;
  urutan: number;
  hari_berlaku?: string[];
  warna?: string;
  is_fixed?: boolean; // Deprecated
  is_non_jp?: boolean; // NEW
}

export interface UpdateTimeBlockInput extends Partial<CreateTimeBlockInput> {}

export interface AssignTimeBlockToKelasInput {
  kelas_id: number;
  time_block_id: number;
  hari?: string | null;
}

export interface CreateMapelKelasInput {
  kelas_id: number;
  mapel_id: number;
  guru_id?: number;
  jumlah_jam_per_minggu: number;
}

export interface UpdateMapelKelasInput extends Partial<CreateMapelKelasInput> {}

export interface CreateTeacherInput {
  nama: string;
  jam_maks: number;
  hari_tidak_bisa?: string;
}

export interface UpdateTeacherInput extends Partial<CreateTeacherInput> {}

export interface CreateSubjectInput {
  nama_mapel: string;
}

export interface UpdateSubjectInput extends Partial<CreateSubjectInput> {}

export interface CreateClassInput {
  nama_kelas: string;
  tingkat: number;
  jam_mulai?: string;
  jam_selesai?: string;
  hari_operasional?: string[];
  hari_aktif?: string[]; // NEW
  wali_kelas?: string;
  jumlah_siswa?: number;
}

export interface UpdateClassInput extends Partial<CreateClassInput> {}

// NEW: Fixed Schedule Inputs
export interface CreateFixedScheduleInput {
  kelas_id: number;
  mapel_kelas_id: number;
  time_block_id: number;
  hari: string;
  is_locked?: boolean;
}

export interface UpdateFixedScheduleInput extends Partial<CreateFixedScheduleInput> {}

// =====================================================
// VALIDATION & UTILITY TYPES
// =====================================================

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  details?: {
    kelas_id: number;
    kelas_nama: string;
    per_day: {
      [hari: string]: {
        required_jp: number;
        available_blocks: number;
        diff: number;
      };
    };
  }[];
}

export interface BlocksAvailability {
  kelas_id: number;
  per_day: {
    [hari: string]: number;
  };
  total: number;
}

// NEW: JP Statistics
export interface JPStatistics {
  kelas_id: number;
  kelas_nama: string;
  jp_kurikulum: number; // Total from mapel_kelas
  jp_blocks: number; // Count of lesson blocks (where is_non_jp = false)
  non_jp_blocks: number; // Count of non-JP blocks
  difference: number; // jp_blocks - jp_kurikulum
  is_valid: boolean; // true if jp_blocks >= jp_kurikulum
}

// =====================================================
// CONSTANTS
// =====================================================

export const JENJANG_OPTIONS: { value: Jenjang; label: string }[] = [
  { value: 'TK', label: 'TK (Taman Kanak-kanak)' },
  { value: 'PAUD', label: 'PAUD' },
  { value: 'SD', label: 'SD (Sekolah Dasar)' },
  { value: 'MI', label: 'MI (Madrasah Ibtidaiyah)' },
  { value: 'SMP', label: 'SMP (Sekolah Menengah Pertama)' },
  { value: 'MTs', label: 'MTs (Madrasah Tsanawiyah)' },
  { value: 'SMA', label: 'SMA (Sekolah Menengah Atas)' },
  { value: 'MA', label: 'MA (Madrasah Aliyah)' },
  { value: 'SMK', label: 'SMK (Sekolah Menengah Kejuruan)' },
];

export const MODEL_SEKOLAH_OPTIONS: { value: ModelSekolah; label: string }[] = [
  { value: 'Reguler', label: 'Reguler' },
  { value: 'Boarding', label: 'Boarding School' },
  { value: 'Mandiri', label: 'Sekolah Mandiri' },
  { value: 'Internasional', label: 'Internasional' },
];

export const TIPE_BLOCK_OPTIONS: { value: TipeBlock; label: string; color: string }[] = [
  { value: 'lesson', label: 'Jam Pelajaran', color: '#4F46E5' },
  { value: 'break', label: 'Istirahat', color: '#10B981' },
  { value: 'prayer', label: 'Ibadah', color: '#8B5CF6' },
  { value: 'event', label: 'Kegiatan', color: '#F59E0B' },
];

export const HARI_OPTIONS = [
  'Senin',
  'Selasa',
  'Rabu',
  'Kamis',
  'Jumat',
  'Sabtu',
  'Minggu',
];