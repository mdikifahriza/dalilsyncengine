// src/services/fixedScheduleService.ts
// Service for managing fixed/locked schedule slots (JP Tetap)

import { supabase } from '@/lib/supabase';
import type {
  FixedSchedule,
  FixedScheduleWithRelations,
  CreateFixedScheduleInput,
  UpdateFixedScheduleInput,
} from '@/types/database.types';

export const fixedScheduleService = {
  /**
   * Get all fixed schedules for a class
   */
  async getByKelas(kelasId: number): Promise<FixedScheduleWithRelations[]> {
    const { data, error } = await supabase
      .from('fixed_schedules')
      .select(`
        *,
        kelas:kelas_id(*),
        mapel_kelas:mapel_kelas_id(*),
        time_block:time_block_id(*)
      `)
      .eq('kelas_id', kelasId)
      .order('hari', { ascending: true });

    if (error) throw new Error(error.message);
    return data as FixedScheduleWithRelations[];
  },

  /**
   * Get all fixed schedules for user
   */
  async getByUser(userId: string): Promise<FixedScheduleWithRelations[]> {
    const { data, error } = await supabase
      .from('fixed_schedules')
      .select(`
        *,
        kelas:kelas_id(*),
        mapel_kelas:mapel_kelas_id(*),
        time_block:time_block_id(*)
      `)
      .eq('user_id', userId)
      .order('kelas_id', { ascending: true });

    if (error) throw new Error(error.message);
    return data as FixedScheduleWithRelations[];
  },

  /**
   * Create fixed schedule
   */
  async create(
    userId: string,
    input: CreateFixedScheduleInput
  ): Promise<FixedSchedule> {
    const { data, error } = await supabase
      .from('fixed_schedules')
      .insert({
        user_id: userId,
        ...input,
      })
      .select()
      .single();

    if (error) throw new Error(error.message);
    return data;
  },

  /**
   * Update fixed schedule
   */
  async update(
    id: number,
    userId: string,
    input: UpdateFixedScheduleInput
  ): Promise<FixedSchedule> {
    const { data, error } = await supabase
      .from('fixed_schedules')
      .update(input)
      .eq('id', id)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw new Error(error.message);
    return data;
  },

  /**
   * Delete fixed schedule
   */
  async delete(id: number, userId: string): Promise<void> {
    const { error } = await supabase
      .from('fixed_schedules')
      .delete()
      .eq('id', id)
      .eq('user_id', userId);

    if (error) throw new Error(error.message);
  },

  /**
   * Delete all fixed schedules for a class
   */
  async deleteByKelas(kelasId: number, userId: string): Promise<void> {
    const { error } = await supabase
      .from('fixed_schedules')
      .delete()
      .eq('kelas_id', kelasId)
      .eq('user_id', userId);

    if (error) throw new Error(error.message);
  },

  /**
   * Check if time block + day is already used
   */
  async isSlotUsed(
    kelasId: number,
    timeBlockId: number,
    hari: string,
    excludeId?: number
  ): Promise<boolean> {
    let query = supabase
      .from('fixed_schedules')
      .select('id', { count: 'exact', head: true })
      .eq('kelas_id', kelasId)
      .eq('time_block_id', timeBlockId)
      .eq('hari', hari);

    if (excludeId) {
      query = query.neq('id', excludeId);
    }

    const { count, error } = await query;
    if (error) throw new Error(error.message);
    return (count || 0) > 0;
  },

  /**
   * Get count of fixed schedules per class
   */
  async getCountByKelas(kelasId: number): Promise<number> {
    const { count, error } = await supabase
      .from('fixed_schedules')
      .select('*', { count: 'exact', head: true })
      .eq('kelas_id', kelasId);

    if (error) throw new Error(error.message);
    return count || 0;
  },
};