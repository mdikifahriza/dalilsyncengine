// src/services/scheduleService.ts - CORRECTED VERSION
import { supabase } from '@/lib/supabase';
import type { ScheduleSlot } from '@/types/database.types';

export interface CreateScheduleSlotInput {
  ga_run_id: number;
  kelas_id: number;
  guru_id: number;
  mapel_id: number;
  hari: string;
  time_block_id?: number;
  jam_ke?: number;
}

export interface ScheduleSlotWithDetails extends ScheduleSlot {
  kelas: { 
    id: number; 
    nama_kelas: string;
    tingkat?: number;
    hari_aktif?: string[];
  };
  guru: { 
    id: number; 
    nama: string;
    jam_maks?: number;
    hari_tidak_bisa?: string;
  };
  mapel: { 
    id: number; 
    nama_mapel: string;
  };
  time_block?: { 
    id: number; 
    nama_block: string; 
    jam_mulai: string; 
    jam_selesai: string;
    tipe_block: string;
    is_fixed?: boolean;
    is_non_jp?: boolean;
    urutan: number;
    warna?: string;
  };
}

export const scheduleService = {

  /**
   * Insert multiple schedule slots at once
   */
  async saveBulk(slots: CreateScheduleSlotInput[]): Promise<ScheduleSlot[]> {
    try {
      const { data, error } = await supabase
        .from('jadwal_slot')
        .insert(slots)
        .select();

      if (error) {
        console.error('Error saving schedule slots:', error);
        throw new Error(error.message);
      }
      
      return data || [];
    } catch (error: any) {
      console.error('Error in saveBulk:', error);
      throw error;
    }
  },

  /**
   * Get schedule by GA run ID with full details
   */
  async getByGARunId(gaRunId: number): Promise<ScheduleSlotWithDetails[]> {
    try {
      const { data, error } = await supabase
        .from('jadwal_slot')
        .select(`
          *,
          kelas:kelas_id (
            id, 
            nama_kelas,
            tingkat,
            hari_aktif
          ),
          guru:guru_id (
            id, 
            nama,
            jam_maks,
            hari_tidak_bisa
          ),
          mapel:mapel_id (
            id, 
            nama_mapel
          ),
          time_block:time_blocks!jadwal_slot_time_block_id_fkey (
            id, 
            nama_block, 
            jam_mulai, 
            jam_selesai,
            tipe_block,
            is_fixed,
            is_non_jp,
            urutan,
            warna
          )
        `)
        .eq('ga_run_id', gaRunId)
        .order('hari', { ascending: true })
        .order('jam_ke', { ascending: true });

      if (error) {
        console.error('Error fetching schedule:', error);
        throw new Error(error.message);
      }
      
      return (data as any) || [];
    } catch (error: any) {
      console.error('Error in getByGARunId:', error);
      throw error;
    }
  },

  /**
   * Get schedule for specific class
   */
  async getByClass(gaRunId: number, kelasId: number): Promise<ScheduleSlotWithDetails[]> {
    try {
      const { data, error } = await supabase
        .from('jadwal_slot')
        .select(`
          *,
          kelas:kelas_id (
            id, 
            nama_kelas,
            tingkat,
            hari_aktif
          ),
          guru:guru_id (
            id, 
            nama,
            jam_maks,
            hari_tidak_bisa
          ),
          mapel:mapel_id (
            id, 
            nama_mapel
          ),
          time_block:time_blocks!jadwal_slot_time_block_id_fkey (
            id, 
            nama_block, 
            jam_mulai, 
            jam_selesai,
            tipe_block,
            is_fixed,
            is_non_jp,
            urutan,
            warna
          )
        `)
        .eq('ga_run_id', gaRunId)
        .eq('kelas_id', kelasId)
        .order('hari', { ascending: true })
        .order('jam_ke', { ascending: true });

      if (error) {
        console.error('Error fetching class schedule:', error);
        throw new Error(error.message);
      }
      
      return (data as any) || [];
    } catch (error: any) {
      console.error('Error in getByClass:', error);
      throw error;
    }
  },

  /**
   * Get schedule for specific teacher
   */
  async getByTeacher(gaRunId: number, guruId: number): Promise<ScheduleSlotWithDetails[]> {
    try {
      const { data, error } = await supabase
        .from('jadwal_slot')
        .select(`
          *,
          kelas:kelas_id (
            id, 
            nama_kelas,
            tingkat,
            hari_aktif
          ),
          guru:guru_id (
            id, 
            nama,
            jam_maks,
            hari_tidak_bisa
          ),
          mapel:mapel_id (
            id, 
            nama_mapel
          ),
          time_block:time_blocks!jadwal_slot_time_block_id_fkey (
            id, 
            nama_block, 
            jam_mulai, 
            jam_selesai,
            tipe_block,
            is_fixed,
            is_non_jp,
            urutan,
            warna
          )
        `)
        .eq('ga_run_id', gaRunId)
        .eq('guru_id', guruId)
        .order('hari', { ascending: true })
        .order('jam_ke', { ascending: true });

      if (error) {
        console.error('Error fetching teacher schedule:', error);
        throw new Error(error.message);
      }
      
      return (data as any) || [];
    } catch (error: any) {
      console.error('Error in getByTeacher:', error);
      throw error;
    }
  },

  /**
   * Delete all schedule slots for a specific GA Run
   */
  async deleteGaRunById(gaRunId: number): Promise<void> {
    try {
      const { error } = await supabase
        .from('jadwal_slot')
        .delete()
        .eq('ga_run_id', gaRunId);

      if (error) {
        console.error('Error deleting schedule slots:', error);
        throw new Error(error.message);
      }
    } catch (error: any) {
      console.error('Error in deleteGaRunById:', error);
      throw error;
    }
  },

  /**
   * Delete GA Run record (use gaService.delete instead)
   */
  async deleteByGARunId(id: number): Promise<void> {
    try {
      // First delete all schedule slots
      await this.deleteGaRunById(id);
      
      // Then delete the GA run record
      const { error } = await supabase
        .from('ga_run')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting GA run:', error);
        throw new Error(error.message);
      }
    } catch (error: any) {
      console.error('Error in deleteByGARunId:', error);
      throw error;
    }
  },

  /**
   * Check for scheduling conflicts
   */
  async checkConflicts(gaRunId: number): Promise<{
    teacherConflicts: Array<{
      key: string;
      slots: ScheduleSlot[];
      description: string;
    }>;
    classConflicts: Array<{
      key: string;
      slots: ScheduleSlot[];
      description: string;
    }>;
  }> {
    try {
      const { data: slots, error } = await supabase
        .from('jadwal_slot')
        .select(`
          *,
          kelas:kelas_id (nama_kelas),
          guru:guru_id (nama),
          mapel:mapel_id (nama_mapel)
        `)
        .eq('ga_run_id', gaRunId);

      if (error) {
        console.error('Error checking conflicts:', error);
        throw new Error(error.message);
      }

      const teacherConflicts: Array<{
        key: string;
        slots: any[];
        description: string;
      }> = [];
      
      const classConflicts: Array<{
        key: string;
        slots: any[];
        description: string;
      }> = [];

      // Check teacher conflicts (same teacher, same time)
      const teacherMap = new Map<string, any[]>();
      slots?.forEach(slot => {
        const timeKey = slot.time_block_id || `jam-${slot.jam_ke}`;
        const key = `${slot.guru_id}-${slot.hari}-${timeKey}`;
        
        if (!teacherMap.has(key)) {
          teacherMap.set(key, []);
        }
        teacherMap.get(key)!.push(slot);
      });

      teacherMap.forEach((slotArray, key) => {
        if (slotArray.length > 1) {
          const firstSlot = slotArray[0];
          teacherConflicts.push({
            key,
            slots: slotArray,
            description: `Guru ${firstSlot.guru?.nama || 'Unknown'} mengajar ${slotArray.length} kelas di waktu yang sama (${firstSlot.hari})`
          });
        }
      });

      // Check class conflicts (same class, same time)
      const classMap = new Map<string, any[]>();
      slots?.forEach(slot => {
        const timeKey = slot.time_block_id || `jam-${slot.jam_ke}`;
        const key = `${slot.kelas_id}-${slot.hari}-${timeKey}`;
        
        if (!classMap.has(key)) {
          classMap.set(key, []);
        }
        classMap.get(key)!.push(slot);
      });

      classMap.forEach((slotArray, key) => {
        if (slotArray.length > 1) {
          const firstSlot = slotArray[0];
          classConflicts.push({
            key,
            slots: slotArray,
            description: `Kelas ${firstSlot.kelas?.nama_kelas || 'Unknown'} memiliki ${slotArray.length} mata pelajaran di waktu yang sama (${firstSlot.hari})`
          });
        }
      });

      return { 
        teacherConflicts,
        classConflicts
      };
    } catch (error: any) {
      console.error('Error in checkConflicts:', error);
      throw error;
    }
  },

  /**
   * Get statistics for a schedule
   */
  async getStatistics(gaRunId: number): Promise<{
    totalSlots: number;
    totalClasses: number;
    totalTeachers: number;
    slotsByDay: Record<string, number>;
  }> {
    try {
      const slots = await this.getByGARunId(gaRunId);
      
      const uniqueClasses = new Set(slots.map(s => s.kelas_id));
      const uniqueTeachers = new Set(slots.map(s => s.guru_id));
      
      const slotsByDay: Record<string, number> = {};
      slots.forEach(slot => {
        slotsByDay[slot.hari] = (slotsByDay[slot.hari] || 0) + 1;
      });

      return {
        totalSlots: slots.length,
        totalClasses: uniqueClasses.size,
        totalTeachers: uniqueTeachers.size,
        slotsByDay
      };
    } catch (error: any) {
      console.error('Error getting statistics:', error);
      throw error;
    }
  }
};