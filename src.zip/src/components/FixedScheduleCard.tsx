// src/components/FixedScheduleCard.tsx
import { motion } from 'framer-motion';
import { Edit2, Trash2, Lock } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import type { FixedScheduleWithRelations } from '@/types/database.types';

interface FixedScheduleCardProps {
  fixedSchedules: FixedScheduleWithRelations[];
  onEdit: (schedule: FixedScheduleWithRelations) => void;
  onDelete: (id: number) => void;
  isLoading?: boolean;
}

export default function FixedScheduleCard({
  fixedSchedules,
  onEdit,
  onDelete,
  isLoading = false,
}: FixedScheduleCardProps) {
  // Group by hari
  const groupedByHari = fixedSchedules.reduce(
    (acc, schedule) => {
      const hari = schedule.hari || 'Semua Hari';
      if (!acc[hari]) acc[hari] = [];
      acc[hari].push(schedule);
      return acc;
    },
    {} as Record<string, FixedScheduleWithRelations[]>
  );

  const hariOrder = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
  const sortedHari = Object.keys(groupedByHari).sort(
    (a, b) => hariOrder.indexOf(a) - hariOrder.indexOf(b)
  );

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto mb-2"></div>
          <p className="text-sm text-gray-600">Memuat jadwal tetap...</p>
        </CardContent>
      </Card>
    );
  }

  if (fixedSchedules.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base sm:text-lg flex items-center gap-2">
            <Lock className="w-5 h-5 text-amber-600" />
            Jadwal Tetap (JP Tetap)
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Lock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-sm text-gray-500">Belum ada jadwal tetap</p>
          <p className="text-xs text-gray-400 mt-1">
            Jadwal tetap tidak akan diacak oleh Genetic Algorithm
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base sm:text-lg flex items-center gap-2">
          <Lock className="w-5 h-5 text-amber-600" />
          Jadwal Tetap (JP Tetap)
          <span className="ml-auto text-sm font-normal text-gray-600 bg-amber-100 px-2 py-1 rounded">
            {fixedSchedules.length} jadwal
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {sortedHari.map((hari, dayIndex) => (
          <motion.div
            key={hari}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: dayIndex * 0.05 }}
          >
            <div className="mb-2">
              <h4 className="text-sm font-semibold text-gray-900 px-3 py-1">
                {hari}
              </h4>
            </div>
            <div className="space-y-2 pl-2 border-l-4 border-amber-300">
              {groupedByHari[hari]
                .sort((a, b) => {
                  const timeA = a.time_block?.jam_mulai || '00:00';
                  const timeB = b.time_block?.jam_mulai || '00:00';
                  return timeA.localeCompare(timeB);
                })
                .map((schedule, index) => (
                  <motion.div
                    key={schedule.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: (dayIndex * 10 + index) * 0.02 }}
                    className="bg-amber-50 rounded-lg p-3 border border-amber-200 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        {/* Time Block */}
                        <div className="flex items-center gap-2 mb-1">
                          <div className="text-center flex-shrink-0 w-16">
                            <p className="text-xs font-mono font-bold text-gray-900">
                              {schedule.time_block?.jam_mulai.slice(0, 5)}
                            </p>
                            <p className="text-xs text-gray-600">
                              {schedule.time_block?.jam_selesai.slice(0, 5)}
                            </p>
                          </div>
                          <div
                            className="w-1 h-10 rounded flex-shrink-0"
                            style={{ backgroundColor: schedule.time_block?.warna || '#4F46E5' }}
                          />
                          <div className="flex-1 min-w-0">
                            <h5 className="text-sm font-semibold text-gray-900 truncate">
                              {schedule.time_block?.nama_block}
                            </h5>
                            <p className="text-xs text-gray-600">
                              {schedule.time_block?.jam_mulai &&
                                schedule.time_block?.jam_selesai &&
                                (() => {
                                  const start = schedule.time_block.jam_mulai.slice(0, 5);
                                  const end = schedule.time_block.jam_selesai.slice(0, 5);
                                  const [startH, startM] = start.split(':').map(Number);
                                  const [endH, endM] = end.split(':').map(Number);
                                  const duration =
                                    endH * 60 + endM - (startH * 60 + startM);
                                  return `${duration} menit`;
                                })()}
                            </p>
                          </div>
                        </div>

                        {/* Subject & Teacher */}
                        <div className="mt-2 pt-2 border-t border-amber-200">
                          <p className="text-xs font-medium text-amber-900 mb-1">
                            📚 Mata Pelajaran:
                          </p>
                          <p className="text-sm font-semibold text-gray-900">
                            {schedule.mapel_kelas?.mapel?.nama_mapel || '—'}
                          </p>
                          <p className="text-xs text-gray-600 mt-1">
                            👨‍🏫 {schedule.mapel_kelas?.guru?.nama || 'Belum ditugaskan'}
                          </p>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-1 flex-shrink-0">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(schedule)}
                          className="h-8 w-8"
                          title="Edit jadwal tetap"
                        >
                          <Edit2 className="w-4 h-4 text-blue-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onDelete(schedule.id)}
                          className="h-8 w-8"
                          title="Hapus jadwal tetap"
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
            </div>
          </motion.div>
        ))}
      </CardContent>
    </Card>
  );
}