// src/components/modals/CopyBlocksModal.tsx
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Copy, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import type { ClassGroup } from '@/types/database.types';

interface CopyBlocksModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentKelasId: number;
  currentHari: string | null;
  availableClasses: ClassGroup[];
  onCopy: (sourceKelasId: number, sourceHari: string | null) => Promise<void>;
}

const HARI_OPTIONS = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];

export default function CopyBlocksModal({
  isOpen,
  onClose,
  currentKelasId,
  currentHari,
  availableClasses,
  onCopy,
}: CopyBlocksModalProps) {
  const [selectedKelasId, setSelectedKelasId] = useState<string>('');
  const [selectedHari, setSelectedHari] = useState<string>('all');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const otherClasses = availableClasses.filter((k) => k.id !== currentKelasId);

  const handleCopy = async () => {
    if (!selectedKelasId) {
      setError('Pilih kelas sumber terlebih dahulu');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const sourceHari = selectedHari === 'all' ? null : selectedHari;
      await onCopy(parseInt(selectedKelasId), sourceHari);
      onClose();
      setSelectedKelasId('');
      setSelectedHari('all');
    } catch (err: any) {
      setError(err.message || 'Gagal menyalin blok waktu');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-xl shadow-2xl w-full max-w-md"
          >
            <div className="border-b border-gray-200 px-4 sm:px-6 py-4 flex items-center justify-between">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900">Copy Blok Waktu</h2>
              <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-6 space-y-4">
              {otherClasses.length === 0 ? (
                <div className="text-center py-8">
                  <Copy className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">Tidak ada kelas lain tersedia</p>
                  <p className="text-sm text-gray-400 mt-1">Buat kelas baru untuk menyalin blok waktu</p>
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Kelas Sumber
                    </label>
                    <select
                      value={selectedKelasId}
                      onChange={(e) => {
                        setSelectedKelasId(e.target.value);
                        setError(null);
                      }}
                      className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="">-- Pilih Kelas --</option>
                      {otherClasses.map((kelas) => (
                        <option key={kelas.id} value={kelas.id}>
                          {kelas.nama_kelas}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Hari Sumber
                    </label>
                    <select
                      value={selectedHari}
                      onChange={(e) => setSelectedHari(e.target.value)}
                      className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="all">Semua Hari</option>
                      {HARI_OPTIONS.map((hari) => (
                        <option key={hari} value={hari}>
                          {hari}
                        </option>
                      ))}
                    </select>
                  </div>

                  {error && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-sm text-red-600">{error}</p>
                    </div>
                  )}

                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-xs text-blue-900">
                      <strong>Info:</strong> Ini akan menyalin semua blok waktu dari kelas/hari sumber ke{' '}
                      {currentHari || 'semua hari'} kelas saat ini.
                    </p>
                  </div>
                </>
              )}

              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="w-full sm:flex-1"
                  disabled={loading}
                >
                  Batal
                </Button>
                {otherClasses.length > 0 && (
                  <Button
                    onClick={handleCopy}
                    className="w-full sm:flex-1"
                    disabled={loading || !selectedKelasId}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Menyalin...
                      </>
                    ) : (
                      <>
                        <Copy className="w-5 h-5 mr-2" />
                        Salin
                      </>
                    )}
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}