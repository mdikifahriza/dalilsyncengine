// src/components/modals/FixedScheduleModal.tsx
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Alert, AlertDescription } from '@/components/ui/Alert';
import type {
  FixedScheduleWithRelations,
  MapelKelasWithRelations,
  TimeBlock,
} from '@/types/database.types';
import { HARI_OPTIONS } from '@/types/database.types';
import { curriculumService } from '@/services/curriculumService';

interface FixedScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  fixedSchedule: FixedScheduleWithRelations | null;
  kelasId: number;
  timeBlocks: TimeBlock[];
  onSave: (data: {
    time_block_id: number;
    mapel_kelas_id: number;
    hari: string;
  }) => Promise<void>;
}

export default function FixedScheduleModal({
  isOpen,
  onClose,
  fixedSchedule,
  kelasId,
  timeBlocks,
  onSave,
}: FixedScheduleModalProps) {
  const [formData, setFormData] = useState({
    time_block_id: 0,
    mapel_kelas_id: 0,
    hari: 'Senin',
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [availableMapels, setAvailableMapels] = useState<MapelKelasWithRelations[]>([]);
  const [mapelsLoading, setMapelsLoading] = useState(false);
  const [selectedMapel, setSelectedMapel] = useState<MapelKelasWithRelations | null>(null);
  const [selectedTimeBlock, setSelectedTimeBlock] = useState<TimeBlock | null>(null);

  useEffect(() => {
    if (isOpen && kelasId) {
      loadAvailableMapels();
    }
  }, [isOpen, kelasId]);

  useEffect(() => {
    if (fixedSchedule) {
      setFormData({
        time_block_id: fixedSchedule.time_block_id,
        mapel_kelas_id: fixedSchedule.mapel_kelas_id,
        hari: fixedSchedule.hari || 'Senin',
      });
      setSelectedMapel(fixedSchedule.mapel_kelas);
      setSelectedTimeBlock(fixedSchedule.time_block);
    } else {
      setFormData({
        time_block_id: 0,
        mapel_kelas_id: 0,
        hari: 'Senin',
      });
      setSelectedMapel(null);
      setSelectedTimeBlock(null);
    }
    setErrors({});
  }, [fixedSchedule, isOpen]);

  const loadAvailableMapels = async () => {
    setMapelsLoading(true);
    try {
      const mapels = await curriculumService.getByKelas(kelasId);
      const jpMapels = mapels.filter((m) => m.jumlah_jam_per_minggu > 0);
      setAvailableMapels(jpMapels);
    } catch (err) {
      console.error('Error loading mapels:', err);
    } finally {
      setMapelsLoading(false);
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.time_block_id) {
      newErrors.time_block_id = 'Blok waktu wajib dipilih';
    }

    if (!formData.mapel_kelas_id) {
      newErrors.mapel_kelas_id = 'Mata pelajaran wajib dipilih';
    }

    if (!selectedMapel?.guru_id) {
      newErrors.guru = 'Mata pelajaran harus memiliki guru yang ditugaskan';
    }

    if (!formData.hari) {
      newErrors.hari = 'Hari wajib dipilih';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) return;

    setLoading(true);
    try {
      await onSave(formData);
    } finally {
      setLoading(false);
    }
  };

  const handleTimeBlockChange = (blockId: number) => {
    const block = timeBlocks.find((b) => b.id === blockId);
    setFormData({
      ...formData,
      time_block_id: blockId,
    });
    setSelectedTimeBlock(block || null);
  };

  const handleMapelChange = (mapelId: number) => {
    const mapel = availableMapels.find((m) => m.id === mapelId);
    setFormData({
      ...formData,
      mapel_kelas_id: mapelId,
    });
    setSelectedMapel(mapel || null);
  };

  const jpTimeBlocks = timeBlocks.filter((b) => b.tipe_block === 'lesson' && !b.is_non_jp);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
          >
            <div className="sticky top-0 bg-white border-b border-gray-200 px-4 sm:px-6 py-4 flex items-center justify-between z-10">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900">
                {fixedSchedule ? 'Edit Jadwal Tetap' : 'Tambah Jadwal Tetap'}
              </h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5">
              <Alert className="bg-amber-50 border-amber-200">
                <AlertCircle className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-sm text-amber-800">
                  Jadwal tetap <strong>tidak akan diacak oleh Genetic Algorithm</strong> saat generate jadwal.
                </AlertDescription>
              </Alert>

              <div className="space-y-5">
                {/* Time Block Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Blok Waktu <span className="text-red-500">*</span>
                  </label>
                  {jpTimeBlocks.length === 0 ? (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription className="text-xs">
                        Tidak ada blok waktu JP. Silakan buat blok waktu terlebih dahulu.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <select
                      value={formData.time_block_id}
                      onChange={(e) => handleTimeBlockChange(Number(e.target.value))}
                      className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="">Pilih Blok Waktu</option>
                      {jpTimeBlocks.map((block) => (
                        <option key={block.id} value={block.id}>
                          {block.nama_block} ({block.jam_mulai.slice(0, 5)} - {block.jam_selesai.slice(0, 5)})
                        </option>
                      ))}
                    </select>
                  )}
                  {errors.time_block_id && (
                    <p className="text-sm text-red-600 mt-1">{errors.time_block_id}</p>
                  )}

                  {selectedTimeBlock && (
                    <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <p className="text-xs text-blue-700 font-medium mb-2">Preview Blok:</p>
                      <div className="flex items-center gap-3">
                        <div
                          className="w-2 h-12 rounded"
                          style={{ backgroundColor: selectedTimeBlock.warna }}
                        />
                        <div>
                          <p className="text-sm font-semibold text-gray-900">
                            {selectedTimeBlock.nama_block}
                          </p>
                          <p className="text-xs text-gray-600">
                            {selectedTimeBlock.jam_mulai.slice(0, 5)} -{' '}
                            {selectedTimeBlock.jam_selesai.slice(0, 5)}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Mapel Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Mata Pelajaran <span className="text-red-500">*</span>
                  </label>
                  {mapelsLoading ? (
                    <div className="h-10 flex items-center text-sm text-gray-600">
                      Memuat mata pelajaran...
                    </div>
                  ) : availableMapels.length === 0 ? (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription className="text-xs">
                        Tidak ada mata pelajaran di kelas ini. Silakan atur kurikulum terlebih dahulu.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <select
                      value={formData.mapel_kelas_id}
                      onChange={(e) => handleMapelChange(Number(e.target.value))}
                      className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="">Pilih Mata Pelajaran</option>
                      {availableMapels.map((mapel) => (
                        <option key={mapel.id} value={mapel.id}>
                          {mapel.mapel?.nama_mapel} ({mapel.jumlah_jam_per_minggu} jam/minggu)
                        </option>
                      ))}
                    </select>
                  )}
                  {errors.mapel_kelas_id && (
                    <p className="text-sm text-red-600 mt-1">{errors.mapel_kelas_id}</p>
                  )}

                  {selectedMapel && (
                    <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <p className="text-xs text-blue-700 font-medium mb-2">Informasi Guru:</p>
                      <p className="text-sm font-semibold text-gray-900">
                        {selectedMapel.guru?.nama || 'Belum ditugaskan'}
                      </p>
                      {!selectedMapel.guru_id && (
                        <p className="text-xs text-red-600 mt-1">
                          ⚠️ Guru belum ditugaskan. Silakan atur di halaman Kurikulum.
                        </p>
                      )}
                    </div>
                  )}
                  {errors.guru && (
                    <p className="text-sm text-red-600 mt-1">{errors.guru}</p>
                  )}
                </div>

                {/* Hari Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Hari <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.hari}
                    onChange={(e) => setFormData({ ...formData, hari: e.target.value })}
                    className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {HARI_OPTIONS.map((hari) => (
                      <option key={hari} value={hari}>
                        {hari}
                      </option>
                    ))}
                  </select>
                  {errors.hari && (
                    <p className="text-sm text-red-600 mt-1">{errors.hari}</p>
                  )}
                </div>
              </div>

              {/* Preview Summary */}
              {selectedTimeBlock && selectedMapel && (
                <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg border-2 border-amber-300">
                  <p className="text-xs font-medium text-amber-900 mb-3">📋 Ringkasan Jadwal Tetap:</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Blok Waktu:</span>
                      <span className="font-semibold text-gray-900">{selectedTimeBlock.nama_block}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Waktu:</span>
                      <span className="font-semibold text-gray-900">
                        {selectedTimeBlock.jam_mulai.slice(0, 5)} - {selectedTimeBlock.jam_selesai.slice(0, 5)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Mata Pelajaran:</span>
                      <span className="font-semibold text-gray-900">
                        {selectedMapel.mapel?.nama_mapel}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Guru:</span>
                      <span className="font-semibold text-gray-900">
                        {selectedMapel.guru?.nama || 'TBD'}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-amber-300 pt-2 mt-2">
                      <span className="text-gray-700">Hari:</span>
                      <span className="font-semibold text-amber-900">{formData.hari}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="w-full sm:flex-1"
                  disabled={loading}
                >
                  Batal
                </Button>
                <Button type="submit" className="w-full sm:flex-1" disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Menyimpan...
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5 mr-2" />
                      Simpan
                    </>
                  )}
                </Button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}