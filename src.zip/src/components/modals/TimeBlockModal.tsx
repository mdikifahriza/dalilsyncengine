// src/components/modals/TimeBlockModal.tsx - UPDATED: Fixed Schedule Support
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Alert, AlertDescription } from '@/components/ui/Alert';
import type { TimeBlock, CreateTimeBlockInput, MapelKelasWithRelations } from '@/types/database.types';
import { TIPE_BLOCK_OPTIONS, HARI_OPTIONS } from '@/types/database.types';
import { curriculumService } from '@/services/curriculumService';
import { fixedScheduleService } from '@/services/fixedScheduleService';

interface TimeBlockModalProps {
  isOpen: boolean;
  onClose: () => void;
  timeBlock: TimeBlock | null;
  existingBlocks: TimeBlock[];
  selectedKelasId?: number;
  onSave: (data: CreateTimeBlockInput & { is_fixed?: boolean; mapel_kelas_id?: number; hari_berlaku_fixed?: string[] }) => Promise<void>;
}

export default function TimeBlockModal({
  isOpen,
  onClose,
  timeBlock,
  existingBlocks,
  selectedKelasId,
  onSave,
}: TimeBlockModalProps) {
  const [formData, setFormData] = useState<CreateTimeBlockInput & { is_fixed?: boolean; mapel_kelas_id?: number }>({
    nama_block: '',
    tipe_block: 'lesson',
    jam_mulai: '07:00',
    jam_selesai: '07:45',
    urutan: 1,
    hari_berlaku: undefined,
    warna: '#4F46E5',
    is_non_jp: false,
    is_fixed: false,
    mapel_kelas_id: undefined,
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [availableMapels, setAvailableMapels] = useState<MapelKelasWithRelations[]>([]);
  const [mapelsLoading, setMapelsLoading] = useState(false);
  const [selectedMapelInfo, setSelectedMapelInfo] = useState<MapelKelasWithRelations | null>(null);
  const [hariTerpilih, setHariTerpilih] = useState<string[]>([]);

  // Load available mapels when modal opens and kelas selected
  useEffect(() => {
    if (isOpen && selectedKelasId) {
      loadAvailableMapels();
    }
  }, [isOpen, selectedKelasId]);

  const loadAvailableMapels = async () => {
    if (!selectedKelasId) return;

    setMapelsLoading(true);
    try {
      const mapels = await curriculumService.getByKelas(selectedKelasId);
      // Filter hanya yang tipe_block lesson (JP)
      const jpMapels = mapels.filter(m => m.jumlah_jam_per_minggu > 0);
      setAvailableMapels(jpMapels);
    } catch (err) {
      console.error('Error loading mapels:', err);
    } finally {
      setMapelsLoading(false);
    }
  };

  useEffect(() => {
    if (timeBlock) {
      setFormData({
        nama_block: timeBlock.nama_block,
        tipe_block: timeBlock.tipe_block,
        jam_mulai: timeBlock.jam_mulai.slice(0, 5),
        jam_selesai: timeBlock.jam_selesai.slice(0, 5),
        urutan: timeBlock.urutan,
        hari_berlaku: timeBlock.hari_berlaku || undefined,
        warna: timeBlock.warna,
        is_non_jp: timeBlock.is_non_jp || false,
        is_fixed: false,
        mapel_kelas_id: undefined,
      });
      setHariTerpilih(timeBlock.hari_berlaku || []);
    } else {
      const maxUrutan = Math.max(0, ...existingBlocks.map((b) => b.urutan));
      setFormData({
        nama_block: '',
        tipe_block: 'lesson',
        jam_mulai: '07:00',
        jam_selesai: '07:45',
        urutan: maxUrutan + 1,
        hari_berlaku: undefined,
        warna: '#4F46E5',
        is_non_jp: false,
        is_fixed: false,
        mapel_kelas_id: undefined,
      });
      setHariTerpilih([]);
    }
    setErrors({});
    setSelectedMapelInfo(null);
  }, [timeBlock, isOpen, existingBlocks]);

  // Auto-set warna and is_non_jp based on tipe_block
  useEffect(() => {
    const tipe = TIPE_BLOCK_OPTIONS.find((t) => t.value === formData.tipe_block);
    if (tipe && !timeBlock) {
      setFormData((prev) => ({
        ...prev,
        warna: tipe.color,
        is_non_jp: tipe.value !== 'lesson',
      }));
    }
  }, [formData.tipe_block, timeBlock]);

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.nama_block.trim()) {
      newErrors.nama_block = 'Nama blok wajib diisi';
    }

    if (formData.jam_mulai >= formData.jam_selesai) {
      newErrors.jam_selesai = 'Jam selesai harus lebih besar dari jam mulai';
    }

    // Validate fixed schedule
    if (formData.is_fixed && formData.tipe_block === 'lesson') {
      if (!formData.mapel_kelas_id) {
        newErrors.mapel_kelas_id = 'Mata pelajaran wajib dipilih untuk JP Tetap';
      }
      if (!selectedMapelInfo?.guru_id) {
        newErrors.guru = 'Mata pelajaran harus memiliki guru yang ditugaskan';
      }
      if (hariTerpilih.length === 0) {
        newErrors.hari_berlaku = 'Pilih minimal satu hari untuk JP Tetap';
      }
    }

    const blocksToCheck = timeBlock
      ? existingBlocks.filter((b) => b.id !== timeBlock.id)
      : existingBlocks;

    for (const block of blocksToCheck) {
      const blockStart = block.jam_mulai.slice(0, 5);
      const blockEnd = block.jam_selesai.slice(0, 5);

      if (
        (formData.jam_mulai < blockEnd && formData.jam_selesai > blockStart) ||
        (blockStart < formData.jam_selesai && blockEnd > formData.jam_mulai)
      ) {
        newErrors.jam_mulai = `Overlap dengan ${block.nama_block} (${blockStart}-${blockEnd})`;
        break;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) return;

    setLoading(true);
    try {
      await onSave({
        ...formData,
        hari_berlaku: formData.hari_berlaku?.length ? formData.hari_berlaku : undefined,
        is_fixed: formData.is_fixed || undefined,
        mapel_kelas_id: formData.is_fixed ? formData.mapel_kelas_id : undefined,
        hari_berlaku_fixed: formData.is_fixed ? hariTerpilih : undefined,
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleHari = (hari: string) => {
    const current = formData.hari_berlaku || [];
    if (current.includes(hari)) {
      setFormData({
        ...formData,
        hari_berlaku: current.filter((h) => h !== hari),
      });
    } else {
      setFormData({
        ...formData,
        hari_berlaku: [...current, hari],
      });
    }
  };

  const toggleHariFixed = (hari: string) => {
    if (hariTerpilih.includes(hari)) {
      setHariTerpilih(hariTerpilih.filter((h) => h !== hari));
    } else {
      setHariTerpilih([...hariTerpilih, hari]);
    }
  };

  const handleMapelChange = (mapelKelasId: number) => {
    const selected = availableMapels.find((m) => m.id === mapelKelasId);
    setFormData({
      ...formData,
      mapel_kelas_id: mapelKelasId,
    });
    setSelectedMapelInfo(selected || null);
  };

  const calculateDuration = () => {
    const [startH, startM] = formData.jam_mulai.split(':').map(Number);
    const [endH, endM] = formData.jam_selesai.split(':').map(Number);
    return endH * 60 + endM - (startH * 60 + startM);
  };

  const isJPBlock = formData.tipe_block === 'lesson' && !formData.is_non_jp;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
          >
            <div className="sticky top-0 bg-white border-b border-gray-200 px-4 sm:px-6 py-4 flex items-center justify-between z-10">
              <h2 className="text-lg sm:text-xl font-bold text-gray-900">
                {timeBlock ? 'Edit Blok Waktu' : 'Tambah Blok Waktu'}
              </h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4 sm:space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5">
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nama Blok <span className="text-red-500">*</span>
                  </label>
                  <Input
                    type="text"
                    value={formData.nama_block}
                    onChange={(e) => setFormData({ ...formData, nama_block: e.target.value })}
                    placeholder="Contoh: Jam 1, Istirahat, Sholat Dhuha"
                    className={errors.nama_block ? 'border-red-500' : ''}
                  />
                  {errors.nama_block && (
                    <p className="text-sm text-red-600 mt-1">{errors.nama_block}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Tipe Blok <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.tipe_block}
                    onChange={(e: any) => setFormData({ ...formData, tipe_block: e.target.value })}
                    className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {TIPE_BLOCK_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Urutan <span className="text-red-500">*</span>
                  </label>
                  <Input
                    type="number"
                    min="0"
                    value={formData.urutan}
                    onChange={(e) => setFormData({ ...formData, urutan: parseInt(e.target.value) })}
                  />
                  <p className="text-xs text-gray-500 mt-1">Urutan tampilan</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Jam Mulai <span className="text-red-500">*</span>
                  </label>
                  <Input
                    type="time"
                    value={formData.jam_mulai}
                    onChange={(e) => setFormData({ ...formData, jam_mulai: e.target.value })}
                    className={errors.jam_mulai ? 'border-red-500' : ''}
                  />
                  {errors.jam_mulai && (
                    <p className="text-sm text-red-600 mt-1">{errors.jam_mulai}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Jam Selesai <span className="text-red-500">*</span>
                  </label>
                  <Input
                    type="time"
                    value={formData.jam_selesai}
                    onChange={(e) => setFormData({ ...formData, jam_selesai: e.target.value })}
                    className={errors.jam_selesai ? 'border-red-500' : ''}
                  />
                  {errors.jam_selesai && (
                    <p className="text-sm text-red-600 mt-1">{errors.jam_selesai}</p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Warna</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={formData.warna}
                      onChange={(e) => setFormData({ ...formData, warna: e.target.value })}
                      className="h-10 w-20 rounded border border-gray-300"
                    />
                    <Input
                      type="text"
                      value={formData.warna}
                      onChange={(e) => setFormData({ ...formData, warna: e.target.value })}
                      placeholder="#4F46E5"
                      className="flex-1"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.is_non_jp}
                      onChange={(e) => setFormData({ ...formData, is_non_jp: e.target.checked })}
                      className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                    />
                    <span className="text-sm font-medium text-gray-700">
                      Blok Non-JP (tidak dihitung sebagai jam pelajaran)
                    </span>
                  </label>
                  <p className="text-xs text-gray-500 mt-1 ml-6">
                    Gunakan untuk istirahat, ibadah, atau kegiatan yang bukan jam pelajaran
                  </p>
                </div>

                {/* NEW: Fixed Schedule Section */}
                {isJPBlock && (
                  <div className="sm:col-span-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.is_fixed || false}
                        onChange={(e) => {
                          setFormData({ ...formData, is_fixed: e.target.checked });
                          if (!e.target.checked) {
                            setHariTerpilih([]);
                            setSelectedMapelInfo(null);
                          }
                        }}
                        className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                      />
                      <span className="text-sm font-medium text-gray-700">
                        Jadwal Tetap (tidak akan diacak oleh GA)
                      </span>
                    </label>
                    <p className="text-xs text-gray-500 mt-1 ml-6">
                      Gunakan untuk jam pelajaran yang wajib tetap (misal: Baca Quran setiap pagi)
                    </p>
                  </div>
                )}

                {/* NEW: Mata Pelajaran Dropdown (conditional) */}
                {formData.is_fixed && isJPBlock && (
                  <>
                    <div className="sm:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Mata Pelajaran <span className="text-red-500">*</span>
                      </label>
                      {mapelsLoading ? (
                        <div className="h-10 flex items-center text-sm text-gray-600">
                          Memuat mata pelajaran...
                        </div>
                      ) : availableMapels.length === 0 ? (
                        <Alert variant="destructive">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription className="text-xs">
                            Tidak ada mata pelajaran di kelas ini. Silakan atur kurikulum terlebih dahulu.
                          </AlertDescription>
                        </Alert>
                      ) : (
                        <select
                          value={formData.mapel_kelas_id || ''}
                          onChange={(e) => handleMapelChange(Number(e.target.value))}
                          className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="">Pilih Mata Pelajaran</option>
                          {availableMapels.map((mapel) => (
                            <option key={mapel.id} value={mapel.id}>
                              {mapel.mapel?.nama_mapel} ({mapel.jumlah_jam_per_minggu} jam/minggu)
                            </option>
                          ))}
                        </select>
                      )}
                      {errors.mapel_kelas_id && (
                        <p className="text-sm text-red-600 mt-1">{errors.mapel_kelas_id}</p>
                      )}
                    </div>

                    {/* NEW: Guru Info */}
                    {selectedMapelInfo && (
                      <div className="sm:col-span-2">
                        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <p className="text-xs font-medium text-blue-700 mb-1">Informasi Guru:</p>
                          <p className="text-sm text-blue-900 font-semibold">
                            {selectedMapelInfo.guru?.nama || 'Belum ditugaskan'}
                          </p>
                          {!selectedMapelInfo.guru_id && (
                            <p className="text-xs text-red-600 mt-1">
                              ⚠️ Guru belum ditugaskan untuk mata pelajaran ini. Silakan atur di halaman Kurikulum.
                            </p>
                          )}
                        </div>
                        {errors.guru && (
                          <p className="text-sm text-red-600 mt-1">{errors.guru}</p>
                        )}
                      </div>
                    )}

                    {/* NEW: Hari Berlaku untuk Fixed Schedule */}
                    <div className="sm:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Hari Berlaku <span className="text-red-500">*</span>
                      </label>
                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                        {HARI_OPTIONS.map((hari) => (
                          <label
                            key={hari}
                            className={`flex items-center justify-center p-2 border-2 rounded-lg cursor-pointer transition text-xs sm:text-sm ${
                              hariTerpilih.includes(hari)
                                ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={hariTerpilih.includes(hari)}
                              onChange={() => toggleHariFixed(hari)}
                              className="hidden"
                            />
                            {hari}
                          </label>
                        ))}
                      </div>
                      {errors.hari_berlaku && (
                        <p className="text-sm text-red-600 mt-1">{errors.hari_berlaku}</p>
                      )}
                    </div>
                  </>
                )}
              </div>

              {/* Original Hari Berlaku (untuk non-fixed blocks) */}
              {!formData.is_fixed && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Hari Berlaku (Opsional)
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {HARI_OPTIONS.map((hari) => (
                      <label
                        key={hari}
                        className={`flex items-center justify-center p-2 border-2 rounded-lg cursor-pointer transition text-xs sm:text-sm ${
                          formData.hari_berlaku?.includes(hari)
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={formData.hari_berlaku?.includes(hari) || false}
                          onChange={() => toggleHari(hari)}
                          className="hidden"
                        />
                        {hari}
                      </label>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Kosongkan jika berlaku semua hari</p>
                </div>
              )}

              {/* Preview */}
              <div
                className="p-3 sm:p-4 rounded-lg border-2"
                style={{ borderLeftWidth: '6px', borderLeftColor: formData.warna }}
              >
                <p className="text-xs font-medium text-gray-500 mb-2">Preview:</p>
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="text-center flex-shrink-0" style={{ width: '70px' }}>
                    <p className="text-sm font-mono font-bold">{formData.jam_mulai}</p>
                    <p className="text-xs text-gray-500">{formData.jam_selesai}</p>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900 truncate">
                      {formData.nama_block || '...'}
                    </h3>
                    <p className="text-xs text-gray-600">
                      {calculateDuration()} menit
                      {formData.is_fixed && hariTerpilih.length > 0 && (
                        <> • {hariTerpilih.join(', ')}</>
                      )}
                      {!formData.is_fixed && formData.hari_berlaku && formData.hari_berlaku.length > 0 && (
                        <> • {formData.hari_berlaku.join(', ')}</>
                      )}
                      {formData.is_non_jp && <> • Non-JP</>}
                      {formData.is_fixed && <> • Tetap</>}
                    </p>
                    {formData.is_fixed && selectedMapelInfo && (
                      <p className="text-xs text-indigo-600 font-medium mt-1">
                        📚 {selectedMapelInfo.mapel?.nama_mapel} • {selectedMapelInfo.guru?.nama || 'TBD'}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-200">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="w-full sm:flex-1"
                  disabled={loading}
                >
                  Batal
                </Button>
                <Button type="submit" className="w-full sm:flex-1" disabled={loading}>
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Menyimpan...
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5 mr-2" />
                      Simpan
                    </>
                  )}
                </Button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}