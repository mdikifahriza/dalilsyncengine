// src/components/JPStatsBox.tsx
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, AlertCircle, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { timeBlockService } from '@/services/timeBlockService';
import { useAuth } from '@/context/AuthContext';
import type { JPStatistics } from '@/types/database.types';

interface JPStatsBoxProps {
  selectedKelasId?: number;
}

export default function JPStatsBox({ selectedKelasId }: JPStatsBoxProps) {
  const { user } = useAuth();
  const [stats, setStats] = useState<JPStatistics[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStats = async () => {
      if (!user) return;

      setLoading(true);
      try {
        const data = await timeBlockService.getJPStatistics(user.id);
        setStats(data);
      } catch (error) {
        console.error('Error loading JP stats:', error);
      } finally {
        setLoading(false);
      }
    };

    loadStats();
  }, [user, selectedKelasId]);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            JP Kurikulum vs Blok Waktu
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const filteredStats = selectedKelasId
    ? stats.filter((s) => s.kelas_id === selectedKelasId)
    : stats;

  if (filteredStats.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            JP Kurikulum vs Blok Waktu
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="text-sm text-gray-500">Belum ada data kelas</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
          <BookOpen className="w-5 h-5 text-indigo-600" />
          JP Kurikulum vs Blok Waktu
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {filteredStats.map((stat, index) => {
            const isValid = stat.is_valid;
            const hasWarning = stat.difference < 0;

            return (
              <motion.div
                key={stat.kelas_id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`p-3 rounded-lg border-2 ${
                  isValid
                    ? 'bg-green-50 border-green-200'
                    : 'bg-red-50 border-red-200'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">
                      {stat.kelas_nama}
                    </p>
                    <p className="text-xs text-gray-600 mt-0.5">
                      JP Kurikulum: {stat.jp_kurikulum} | Blok JP: {stat.jp_blocks}
                    </p>
                  </div>
                  {isValid ? (
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 ml-2" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 ml-2" />
                  )}
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className={isValid ? 'text-green-700' : 'text-red-700'}>
                    {isValid ? (
                      hasWarning ? (
                        <>Kelebihan: {Math.abs(stat.difference)} blok</>
                      ) : (
                        <>✓ Sesuai</>
                      )
                    ) : (
                      <>Kurang: {Math.abs(stat.difference)} blok</>
                    )}
                  </span>
                  {stat.non_jp_blocks > 0 && (
                    <span className="text-gray-600">Non-JP: {stat.non_jp_blocks}</span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="mt-4 pt-4 border-t border-gray-200">
          <p className="text-xs text-gray-500">
            💡 <strong>Catatan:</strong> Blok JP harus ≥ JP Kurikulum. Blok Non-JP tidak dihitung.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}