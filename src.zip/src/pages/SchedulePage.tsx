// src/pages/SchedulePage.tsx - FINAL CORRECTED VERSION
// Combines: jadwal_slot (for lesson slots) + time_blocks (for non-JP blocks like break, prayer)
import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

import { 
  Calendar, 
  Download, 
  AlertCircle, 
  Clock, 
  Trash2,
  AlertTriangle,
  Coffee,
  Church,
  Users,
  BookOpen,
  X,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Alert, AlertDescription } from '@/components/ui/Alert';

import { useAuth } from '@/context/AuthContext';
import { gaService, type GARunWithStats } from '@/services/gaService';
import { scheduleService, type ScheduleSlotWithDetails } from '@/services/scheduleService';
import { timeBlockService } from '@/services/timeBlockService';

import { useClasses } from '@/hooks/useClasses';
import { formatDate } from '@/lib/utils';
import type { TimeBlock } from '@/types/database.types';

interface Conflict {
  type: 'teacher' | 'class';
  description: string;
  slots: ScheduleSlotWithDetails[];
  severity: 'high' | 'medium';
}

export default function SchedulePage() {
  const { user } = useAuth();
  const { classes } = useClasses();

  const [gaRuns, setGaRuns] = useState<GARunWithStats[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<number | null>(null);
  const [schedule, setSchedule] = useState<ScheduleSlotWithDetails[]>([]);
  const [timeBlocks, setTimeBlocks] = useState<TimeBlock[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [showConflicts, setShowConflicts] = useState(false);
  const [expandedClasses, setExpandedClasses] = useState<Set<number>>(new Set());

  const exportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) loadGARuns();
  }, [user]);

  useEffect(() => {
    if (selectedRunId) loadSchedule(selectedRunId);
  }, [selectedRunId]);

  const loadGARuns = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const runs = await gaService.getAllWithStats(user!.id);
      setGaRuns(runs);

      const latestSuccess = runs.find(r => r.status === 'completed');
      if (latestSuccess) {
        setSelectedRunId(latestSuccess.id);
      } else if (runs.length > 0) {
        setSelectedRunId(runs[0].id);
      }
    } catch (err: any) {
      console.error('Error loading GA runs:', err);
      setError(err.message || 'Gagal memuat riwayat generate');
    } finally {
      setLoading(false);
    }
  };

  const loadSchedule = async (runId: number) => {
    try {
      setLoading(true);
      setError(null);
      
      // Load both: schedule slots (JP) and time blocks (for non-JP)
      const [scheduleData, timeBlocksData] = await Promise.all([
        scheduleService.getByGARunId(runId),
        timeBlockService.getAll(user!.id)
      ]);
      
      console.log('Schedule data loaded:', scheduleData.length, 'JP slots');
      console.log('Time blocks loaded:', timeBlocksData.length, 'blocks');
      
      setSchedule(scheduleData);
      setTimeBlocks(timeBlocksData);
      
      // Detect conflicts (only on JP slots)
      const detectedConflicts = detectConflicts(scheduleData, timeBlocksData);
      setConflicts(detectedConflicts);
      
      console.log('Conflicts detected:', detectedConflicts.length);
    } catch (err: any) {
      console.error('Error loading schedule:', err);
      setError(err.message || 'Gagal memuat jadwal');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Detect conflicts in schedule (only for JP slots from jadwal_slot)
   */
  const detectConflicts = (
    scheduleData: ScheduleSlotWithDetails[],
    timeBlocksData: TimeBlock[]
  ): Conflict[] => {
    const conflicts: Conflict[] = [];

    // 1. Teacher conflicts (same teacher, same time, different classes)
    const teacherSlots = new Map<string, ScheduleSlotWithDetails[]>();
    
    scheduleData.forEach(slot => {
      const timeKey = slot.time_block_id || `jam-${slot.jam_ke}`;
      const key = `${slot.guru_id}-${slot.hari}-${timeKey}`;
      
      if (!teacherSlots.has(key)) {
        teacherSlots.set(key, []);
      }
      teacherSlots.get(key)!.push(slot);
    });

    teacherSlots.forEach((slots, key) => {
      if (slots.length > 1) {
        const timeBlock = timeBlocksData.find(tb => tb.id === slots[0].time_block_id);
        const timeStr = timeBlock 
          ? `${formatTime(timeBlock.jam_mulai)}-${formatTime(timeBlock.jam_selesai)}`
          : `Jam ${slots[0].jam_ke}`;
        
        conflicts.push({
          type: 'teacher',
          description: `${slots[0].guru?.nama || 'Unknown'} mengajar di ${slots.length} kelas pada ${slots[0].hari} ${timeStr}`,
          slots: slots,
          severity: 'high'
        });
      }
    });

    // 2. Class conflicts (same class, same time, different subjects)
    const classSlots = new Map<string, ScheduleSlotWithDetails[]>();
    
    scheduleData.forEach(slot => {
      const timeKey = slot.time_block_id || `jam-${slot.jam_ke}`;
      const key = `${slot.kelas_id}-${slot.hari}-${timeKey}`;
      
      if (!classSlots.has(key)) {
        classSlots.set(key, []);
      }
      classSlots.get(key)!.push(slot);
    });

    classSlots.forEach((slots, key) => {
      if (slots.length > 1) {
        const timeBlock = timeBlocksData.find(tb => tb.id === slots[0].time_block_id);
        const timeStr = timeBlock 
          ? `${formatTime(timeBlock.jam_mulai)}-${formatTime(timeBlock.jam_selesai)}`
          : `Jam ${slots[0].jam_ke}`;
        
        conflicts.push({
          type: 'class',
          description: `${slots[0].kelas?.nama_kelas || 'Unknown'} memiliki ${slots.length} pelajaran pada ${slots[0].hari} ${timeStr}`,
          slots: slots,
          severity: 'high'
        });
      }
    });

    return conflicts;
  };

  const handleExportPDF = async () => {
    if (!exportRef.current) return;

    try {
      const element = exportRef.current;
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff"
      });

      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("l", "mm", "a4"); // Landscape

      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const imgW = pageW;
      const imgH = (canvas.height * imgW) / canvas.width;

      let yPos = 0;

      if (imgH <= pageH) {
        pdf.addImage(imgData, "PNG", 0, 0, imgW, imgH);
      } else {
        while (yPos < imgH) {
          pdf.addImage(imgData, "PNG", 0, -yPos, imgW, imgH);
          yPos += pageH;
          if (yPos < imgH) pdf.addPage();
        }
      }

      pdf.save(`Jadwal-${formatDate(new Date())}.pdf`);
    } catch (err) {
      console.error('Error exporting PDF:', err);
      alert('Gagal export PDF');
    }
  };

  const handleDelete = async (runId: number) => {
    if (!confirm('Hapus jadwal ini? Tindakan tidak dapat dibatalkan.')) return;

    try {
      await scheduleService.deleteByGARunId(runId);
      await loadGARuns();
      if (selectedRunId === runId) {
        setSelectedRunId(null);
        setSchedule([]);
      }
    } catch (err: any) {
      console.error('Error deleting schedule:', err);
      alert(err.message || 'Gagal menghapus jadwal');
    }
  };

  const formatTime = (time: string): string => {
    if (!time) return '';
    return time.substring(0, 5); // HH:MM
  };

  const getFixedBlockIcon = (type: string) => {
    switch (type) {
      case 'break':
        return <Coffee className="w-4 h-4 text-amber-600" />;
      case 'prayer':
        return <Church className="w-4 h-4 text-purple-600" />;
      case 'event':
        return <Users className="w-4 h-4 text-blue-600" />;
      default:
        return <Clock className="w-4 h-4 text-gray-600" />;
    }
  };

  const toggleClassExpanded = (kelasId: number) => {
    setExpandedClasses(prev => {
      const newSet = new Set(prev);
      if (newSet.has(kelasId)) {
        newSet.delete(kelasId);
      } else {
        newSet.add(kelasId);
      }
      return newSet;
    });
  };

  // Get unique days from schedule
  const uniqueDays = Array.from(new Set(schedule.map(s => s.hari)));
  const hariOperasional = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']
    .filter(hari => uniqueDays.includes(hari));

  // ✅ Get ALL time blocks (both JP and non-JP) sorted by urutan
  const allTimeBlocks = [...timeBlocks].sort((a, b) => a.urutan - b.urutan);

  // Group schedule by class
  const scheduleByClass = classes.map(kelas => {
    const classSchedule = schedule.filter(s => s.kelas_id === kelas.id);
    
    // Get class operating hours from schedule
    const classTimeBlocks = classSchedule
      .map(s => s.time_block)
      .filter((tb): tb is NonNullable<typeof tb> => tb !== null && tb !== undefined);
    
    const earliestBlock = classTimeBlocks.reduce((earliest, block) => {
      if (!earliest) return block;
      return block.jam_mulai < earliest.jam_mulai ? block : earliest;
    }, classTimeBlocks[0]);
    
    const latestBlock = classTimeBlocks.reduce((latest, block) => {
      if (!latest) return block;
      return block.jam_selesai > latest.jam_selesai ? block : latest;
    }, classTimeBlocks[0]);

    return {
      ...kelas,
      schedule: classSchedule,
      jam_mulai: earliestBlock?.jam_mulai,
      jam_selesai: latestBlock?.jam_selesai
    };
  }).filter(k => k.schedule.length > 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6 p-2 md:p-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center gap-2">
            <Calendar className="w-6 h-6 md:w-8 md:h-8" />
            Jadwal Pelajaran
          </h1>
          <p className="text-xs md:text-sm text-gray-600 mt-1">
            Hasil generate jadwal otomatis
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {schedule.length > 0 && (
            <Button
              onClick={handleExportPDF}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span className="hidden md:inline">Export PDF</span>
              <span className="md:hidden">PDF</span>
            </Button>
          )}
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Conflicts Warning */}
      {conflicts.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Alert variant="destructive" className="cursor-pointer" onClick={() => setShowConflicts(!showConflicts)}>
            <AlertTriangle className="w-4 h-4" />
            <AlertDescription className="flex items-center justify-between">
              <span>
                Ditemukan {conflicts.length} konflik dalam jadwal. Klik untuk detail.
              </span>
              {showConflicts ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </AlertDescription>
          </Alert>

          {showConflicts && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-2 space-y-2"
            >
              {conflicts.map((conflict, idx) => (
                <Card key={idx} className="border-red-200 bg-red-50">
                  <CardContent className="p-3 md:p-4">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0 mt-1" />
                      <div className="flex-1 text-sm">
                        <p className="font-semibold text-red-900">{conflict.description}</p>
                        <div className="mt-2 space-y-1 text-xs text-red-700">
                          {conflict.slots.map((slot, i) => (
                            <div key={i}>
                              • {slot.kelas?.nama_kelas || 'Unknown'} - {slot.mapel?.nama_mapel || 'Unknown'} 
                              {slot.time_block && ` (${formatTime(slot.time_block.jam_mulai)})`}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          )}
        </motion.div>
      )}

      {/* GA Run Selection */}
      {gaRuns.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base md:text-lg">Pilih Jadwal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {gaRuns.map((run) => (
                <motion.div
                  key={run.id}
                  whileHover={{ scale: 1.01 }}
                  className={`p-3 md:p-4 border-2 rounded-lg cursor-pointer transition ${
                    selectedRunId === run.id
                      ? 'border-indigo-600 bg-indigo-50'
                      : 'border-gray-200 hover:border-indigo-300'
                  }`}
                  onClick={() => setSelectedRunId(run.id)}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm md:text-base font-semibold">
                          Generate #{run.id}
                        </span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full ${
                            run.status === 'completed'
                              ? 'bg-green-100 text-green-700'
                              : run.status === 'running'
                              ? 'bg-blue-100 text-blue-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {run.status}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        {run.timestamp_start && formatDate(new Date(run.timestamp_start))}
                      </p>
                      {run.final_fitness !== null && (
                        <p className="text-xs text-gray-600">
                          Fitness: {run.final_fitness?.toFixed(2)}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="text-xs text-gray-600">
                        {run.slot_count || 0} slot
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(run.id);
                        }}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Schedule Display */}
      {scheduleByClass.length > 0 ? (
        <div ref={exportRef} className="space-y-4 md:space-y-6">
          {scheduleByClass.map((kelas) => {
            const classSchedule = kelas.schedule;
            const isExpanded = expandedClasses.has(kelas.id);

            return (
              <motion.div
                key={kelas.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="overflow-hidden">
                  <CardHeader 
                    className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white cursor-pointer md:cursor-default"
                    onClick={() => toggleClassExpanded(kelas.id)}
                  >
                    <CardTitle className="flex items-center justify-between">
                      <div>
                        <span className="text-base md:text-xl">{kelas.nama_kelas}</span>
                        {kelas.jam_mulai && kelas.jam_selesai && (
                          <span className="text-xs md:text-sm text-indigo-100 ml-2 block md:inline">
                            Jam: {formatTime(kelas.jam_mulai)} - {formatTime(kelas.jam_selesai)}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs md:text-sm text-indigo-100">
                          {classSchedule.length} JP
                        </span>
                        <div className="md:hidden">
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </div>
                      </div>
                    </CardTitle>
                  </CardHeader>

                  {/* Desktop View - Always visible */}
                  <div className="hidden md:block">
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border border-gray-200 text-xs md:text-sm">
                          <thead>
                            <tr className="bg-gray-50">
                              <th className="border border-gray-200 p-1 md:p-2 text-center w-16 md:w-24">
                                Waktu
                              </th>
                              {hariOperasional.map((hari) => (
                                <th key={hari} className="border border-gray-200 p-1 md:p-2 text-center font-semibold">
                                  {hari}
                                </th>
                              ))}
                            </tr>
                          </thead>

                          <tbody>
                            {allTimeBlocks.map((timeBlock) => {
                              // ✅ Check if this is a non-JP block from time_blocks table
                              const isNonJPBlock = timeBlock.is_non_jp === true;

                              return (
                                <tr key={timeBlock.id} className={isNonJPBlock ? 'bg-gray-100' : ''}>
                                  {/* Time Column */}
                                  <td className="border border-gray-200 p-1 md:p-2 text-center bg-gray-50">
                                    <div className="font-mono text-xs font-bold">
                                      {formatTime(timeBlock.jam_mulai)}
                                    </div>
                                    <div className="font-mono text-xs text-gray-500">
                                      {formatTime(timeBlock.jam_selesai)}
                                    </div>
                                    <div className="text-xs text-gray-600 mt-1 flex items-center justify-center gap-1">
                                      {isNonJPBlock && getFixedBlockIcon(timeBlock.tipe_block)}
                                      <span className="hidden md:inline">{timeBlock.nama_block}</span>
                                    </div>
                                  </td>

                                  {/* ✅ If non-JP block: show as full-width row (break/prayer/event) */}
                                  {isNonJPBlock ? (
                                    <td
                                      colSpan={hariOperasional.length}
                                      className="border border-gray-200 p-2 md:p-3 text-center bg-gradient-to-r from-green-50 to-emerald-50"
                                    >
                                      <div className="flex items-center justify-center gap-2">
                                        {getFixedBlockIcon(timeBlock.tipe_block)}
                                        <span className="font-semibold text-gray-700 text-xs md:text-sm">
                                          {timeBlock.nama_block}
                                        </span>
                                      </div>
                                    </td>
                                  ) : (
                                    /* ✅ If JP block: show lesson slots from jadwal_slot */
                                    hariOperasional.map((hari) => {
                                      // Find slot from jadwal_slot for this time_block_id
                                      const slot = classSchedule.find(
                                        (s) => s.hari === hari && s.time_block_id === timeBlock.id
                                      );

                                      if (!slot) {
                                        return (
                                          <td key={hari} className="border border-gray-200 p-1 md:p-2 bg-gray-50/50"></td>
                                        );
                                      }

                                      return (
                                        <td
                                          key={hari}
                                          className="border border-gray-200 p-1 md:p-2 hover:bg-indigo-50 transition"
                                        >
                                          <div className="space-y-1">
                                            <div className="font-bold text-indigo-700 text-xs">
                                              {slot.mapel?.nama_mapel || 'Unknown'}
                                            </div>
                                            <div className="text-xs text-gray-600">
                                              👤 {slot.guru?.nama || 'Unknown'}
                                            </div>
                                          </div>
                                        </td>
                                      );
                                    })
                                  )}

                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </div>

                  {/* Mobile View - Collapsible */}
                  {isExpanded && (
                    <motion.div
                      className="md:hidden"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                    >
                      <CardContent className="pt-0">
                        {hariOperasional.map((hari) => (
                          <div key={hari} className="mb-4">
                            <h3 className="font-bold text-sm text-indigo-600 mb-2 border-b pb-1">
                              {hari}
                            </h3>
                            <div className="space-y-2">
                              {allTimeBlocks.map((timeBlock) => {
                                const isNonJPBlock = timeBlock.is_non_jp === true;
                                
                                // ✅ Show non-JP blocks (from time_blocks)
                                if (isNonJPBlock) {
                                  return (
                                    <div key={timeBlock.id} className="p-2 bg-green-50 rounded border border-green-200">
                                      <div className="flex items-center gap-2 text-xs">
                                        {getFixedBlockIcon(timeBlock.tipe_block)}
                                        <span className="font-medium">
                                          {formatTime(timeBlock.jam_mulai)} - {formatTime(timeBlock.jam_selesai)}
                                        </span>
                                        <span className="text-gray-600">{timeBlock.nama_block}</span>
                                      </div>
                                    </div>
                                  );
                                }

                                // ✅ Show JP slots (from jadwal_slot)
                                const slot = classSchedule.find(
                                  (s) => s.hari === hari && s.time_block_id === timeBlock.id
                                );

                                if (!slot) return null;

                                return (
                                  <div key={timeBlock.id} className="p-2 bg-white border border-gray-200 rounded">
                                    <div className="flex items-start gap-2">
                                      <div className="flex-shrink-0 text-xs font-mono text-gray-600">
                                        {formatTime(timeBlock.jam_mulai)}
                                      </div>
                                      <div className="flex-1">
                                        <p className="font-bold text-sm text-indigo-700">
                                          {slot.mapel?.nama_mapel || 'Unknown'}
                                        </p>
                                        <p className="text-xs text-gray-600">
                                          👤 {slot.guru?.nama || 'Unknown'}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </motion.div>
                  )}

                </Card>
              </motion.div>
            );
          })}

        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center">
            <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 text-sm md:text-base">
              {selectedRunId 
                ? 'Tidak ada jadwal untuk run yang dipilih'
                : 'Pilih jadwal untuk ditampilkan'}
            </p>
          </CardContent>
        </Card>
      )}

    </div>
  );
}