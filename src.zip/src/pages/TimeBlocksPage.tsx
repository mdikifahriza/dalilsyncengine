// src/pages/TimeBlocksPage.tsx - SIMPLIFIED VERSION
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit2, Trash2, Clock, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Alert, AlertDescription } from '@/components/ui/Alert';
import { useAuth } from '@/context/AuthContext';
import { timeBlockService } from '@/services/timeBlockService';
import { timeBlockKelasService } from '@/services/timeBlockKelasService';
import { useClasses } from '@/hooks/useClasses';
import { useFixedSchedules } from '@/hooks/useFixedSchedules';
import TimeBlockModal from '@/components/modals/TimeBlockModal';
import FixedScheduleCard from '@/components/FixedScheduleCard';
import JPStatsBox from '@/components/JPStatsBox';
import type {
  TimeBlock,
  TimeBlockKelasWithRelations,
  CreateTimeBlockInput,
} from '@/types/database.types';

export default function TimeBlocksPage() {
  const { user } = useAuth();
  const { classes, updateClass } = useClasses();

  const [timeBlocks, setTimeBlocks] = useState<TimeBlock[]>([]);
  const [selectedKelas, setSelectedKelas] = useState<number | null>(null);
  const [assignments, setAssignments] = useState<TimeBlockKelasWithRelations[]>([]);
  const [hariAktif, setHariAktif] = useState<string[]>([
    'Senin',
    'Selasa',
    'Rabu',
    'Kamis',
    'Jumat',
  ]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBlock, setEditingBlock] = useState<TimeBlock | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [showJPStats, setShowJPStats] = useState(false);
  const [showFixedSchedule, setShowFixedSchedule] = useState(false);

  // Fixed schedules hook
  const {
    fixedSchedules,
    loading: fixedLoading,
    createFixedSchedule,
    deleteFixedSchedule,
    fetchFixedSchedules,
  } = useFixedSchedules(selectedKelas || undefined);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  useEffect(() => {
    if (classes.length > 0 && !selectedKelas) {
      setSelectedKelas(classes[0].id);
    }
  }, [classes]);

  useEffect(() => {
    if (selectedKelas) {
      const kelas = classes.find((k) => k.id === selectedKelas);
      if (kelas?.hari_aktif) {
        setHariAktif(kelas.hari_aktif);
      }
      loadAssignments();
      fetchFixedSchedules();
    }
  }, [selectedKelas, classes]);

  const loadData = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const blocks = await timeBlockService.getAll(user.id);
      setTimeBlocks(blocks);
    } catch (err: any) {
      setError(err.message || 'Gagal memuat data');
    } finally {
      setLoading(false);
    }
  };

  const loadAssignments = async () => {
    if (!selectedKelas) return;

    try {
      const data = await timeBlockKelasService.getByKelas(selectedKelas);
      setAssignments(data);
    } catch (err: any) {
      console.error('Error loading assignments:', err);
    }
  };

  const isAssigned = (timeBlockId: number): boolean => {
    return assignments.some((a) => a.time_block_id === timeBlockId);
  };

  const handleCreate = () => {
    setEditingBlock(null);
    setIsModalOpen(true);
  };

  const handleEdit = (block: TimeBlock) => {
    setEditingBlock(block);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: number) => {
    if (!user) return;

    try {
      await timeBlockService.delete(id, user.id);
      setTimeBlocks((prev) => prev.filter((b) => b.id !== id));
      await loadAssignments();
      setDeleteConfirm(null);
    } catch (err: any) {
      alert(err.message || 'Gagal menghapus blok waktu');
    }
  };

  const handleSave = async (data: CreateTimeBlockInput & { 
    is_fixed?: boolean; 
    mapel_kelas_id?: number; 
    hari_berlaku_fixed?: string[] 
  }) => {
    if (!user) return;

    try {
      const { is_fixed, mapel_kelas_id, hari_berlaku_fixed, ...timeBlockData } = data;

      let savedBlock: TimeBlock;
      if (editingBlock) {
        savedBlock = await timeBlockService.update(editingBlock.id, user.id, timeBlockData);
        setTimeBlocks((prev) => prev.map((b) => (b.id === savedBlock.id ? savedBlock : b)));
      } else {
        savedBlock = await timeBlockService.create(user.id, timeBlockData);
        setTimeBlocks((prev) => [...prev, savedBlock].sort((a, b) => a.urutan - b.urutan));
      }

      // Create fixed schedules if needed
      if (is_fixed && mapel_kelas_id && hari_berlaku_fixed && selectedKelas) {
        for (const hari of hari_berlaku_fixed) {
          await createFixedSchedule({
            kelas_id: selectedKelas,
            mapel_kelas_id: mapel_kelas_id,
            time_block_id: savedBlock.id,
            hari: hari,
            is_locked: true,
          });
        }
        await fetchFixedSchedules();
      }

      setIsModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Gagal menyimpan blok waktu');
      throw err;
    }
  };

  const handleDeleteFixedSchedule = async (id: number) => {
    if (!window.confirm('Hapus jadwal tetap ini?')) return;

    try {
      await deleteFixedSchedule(id);
    } catch (err: any) {
      alert(err.message || 'Gagal menghapus jadwal tetap');
    }
  };

  const handleUpdateHariAktif = async (newHariAktif: string[]) => {
    if (!selectedKelas || !user) return;

    try {
      await updateClass(selectedKelas, { hari_aktif: newHariAktif });
      setHariAktif(newHariAktif);
    } catch (err: any) {
      alert(err.message || 'Gagal update hari aktif');
    }
  };

  const toggleHariAktif = (hari: string) => {
    const newHariAktif = hariAktif.includes(hari)
      ? hariAktif.filter((h) => h !== hari)
      : [...hariAktif, hari];

    handleUpdateHariAktif(newHariAktif);
  };

  const getBlockTypeColor = (type: string, isNonJP: boolean) => {
    if (isNonJP) {
      return 'bg-gray-100 text-gray-700 border-gray-300';
    }
    const colors: Record<string, string> = {
      lesson: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      break: 'bg-green-100 text-green-800 border-green-200',
      prayer: 'bg-purple-100 text-purple-800 border-purple-200',
      event: 'bg-amber-100 text-amber-800 border-amber-200',
    };
    return colors[type] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const formatTime = (time: string) => time.slice(0, 5);

  const jpBlocks = timeBlocks.filter((b) => b.tipe_block === 'lesson' && !b.is_non_jp);
  const nonJPBlocks = timeBlocks.filter((b) => b.is_non_jp);
  const selectedClass = classes.find((c) => c.id === selectedKelas);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-indigo-600" />
            Blok Waktu
          </h1>
          <p className="text-sm sm:text-base text-gray-500 mt-1">
            Kelola jam pelajaran untuk generate jadwal
          </p>
        </div>
        <Button onClick={handleCreate} className="w-full sm:w-auto text-sm">
          <Plus className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
          Tambah Blok Waktu
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-sm">{error}</AlertDescription>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-2 sm:gap-4">
        <Card>
          <CardContent className="p-3 sm:p-4">
            <p className="text-xs sm:text-sm text-gray-600">Blok JP</p>
            <p className="text-xl sm:text-2xl font-bold text-indigo-600">{jpBlocks.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 sm:p-4">
            <p className="text-xs sm:text-sm text-gray-600">Blok Non-JP</p>
            <p className="text-xl sm:text-2xl font-bold text-gray-600">{nonJPBlocks.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 sm:p-4">
            <p className="text-xs sm:text-sm text-gray-600">Total</p>
            <p className="text-xl sm:text-2xl font-bold text-green-600">{timeBlocks.length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Class Selector + Hari Aktif */}
      {classes.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base sm:text-lg">Pengaturan Kelas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Class Selector */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Pilih Kelas
              </label>
              <select
                value={selectedKelas || ''}
                onChange={(e) => setSelectedKelas(Number(e.target.value))}
                className="w-full h-10 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {classes.map((kelas) => (
                  <option key={kelas.id} value={kelas.id}>
                    {kelas.nama_kelas}
                  </option>
                ))}
              </select>
            </div>

            {/* Hari Aktif */}
            {selectedClass && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Hari Aktif untuk Generate Jadwal
                </label>
                <div className="flex flex-wrap gap-2">
                  {['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'].map((hari) => (
                    <Button
                      key={hari}
                      variant={hariAktif.includes(hari) ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => toggleHariAktif(hari)}
                      className="text-xs sm:text-sm"
                    >
                      {hari}
                    </Button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Blok waktu akan otomatis berlaku untuk hari yang dipilih
                </p>
              </div>
            )}

            {/* Info */}
            {selectedClass && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-xs sm:text-sm">
                  <strong>{selectedClass.nama_kelas}</strong> memiliki {jpBlocks.length} Blok JP
                  untuk {hariAktif.length} hari aktif
                  {fixedSchedules.length > 0 && <>, dengan {fixedSchedules.length} JP Tetap</>}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Timeline Blok Waktu */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base sm:text-lg">Timeline Blok Waktu</CardTitle>
        </CardHeader>
        <CardContent>
          {timeBlocks.length === 0 ? (
            <div className="text-center py-8 sm:py-12">
              <Clock className="w-12 h-12 sm:w-16 sm:h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2">
                Belum ada blok waktu
              </h3>
              <p className="text-sm sm:text-base text-gray-500 mb-6">
                Mulai dengan menambahkan blok waktu untuk jadwal
              </p>
              <Button onClick={handleCreate} className="text-sm">
                Tambah Blok
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              {timeBlocks.map((block, index) => {
                const assigned = isAssigned(block.id);
                return (
                  <motion.div
                    key={block.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.03 }}
                    className={`flex items-center gap-3 sm:gap-4 p-3 sm:p-4 rounded-lg border-2 ${getBlockTypeColor(
                      block.tipe_block,
                      block.is_non_jp
                    )} ${assigned ? 'ring-2 ring-green-500' : ''}`}
                    style={{ borderLeftWidth: '6px', borderLeftColor: block.warna }}
                  >
                    <div className="flex-shrink-0 text-center w-14 sm:w-20">
                      <p className="text-xs sm:text-sm font-mono font-bold">
                        {formatTime(block.jam_mulai)}
                      </p>
                      <p className="text-xs text-gray-500">{formatTime(block.jam_selesai)}</p>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold text-gray-900 text-sm sm:text-base truncate">
                          {block.nama_block}
                        </h3>
                        {block.is_non_jp && (
                          <span className="px-2 py-0.5 text-xs bg-gray-200 text-gray-700 rounded flex-shrink-0">
                            Non-JP
                          </span>
                        )}
                        {block.tipe_block === 'lesson' && !block.is_non_jp && (
                          <span className="px-2 py-0.5 text-xs bg-blue-100 text-blue-700 rounded flex-shrink-0">
                            JP
                          </span>
                        )}
                        {assigned && (
                          <span className="px-2 py-0.5 text-xs bg-green-100 text-green-700 rounded flex-shrink-0">
                            ✓ Aktif
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        {block.hari_berlaku && block.hari_berlaku.length > 0
                          ? `${block.hari_berlaku.join(', ')}`
                          : `Berlaku untuk: ${hariAktif.join(', ')}`}
                      </p>
                    </div>

                    <div className="flex gap-1 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(block)}
                        className="h-8 w-8 sm:h-10 sm:w-10"
                      >
                        <Edit2 className="w-3 h-3 sm:w-4 sm:h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteConfirm(block.id)}
                        className="h-8 w-8 sm:h-10 sm:w-10"
                      >
                        <Trash2 className="w-3 h-3 sm:w-4 sm:h-4 text-red-600" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* JP Stats (Collapsible) */}
      <div>
        <Button
          variant="outline"
          onClick={() => setShowJPStats(!showJPStats)}
          className="w-full justify-between mb-2"
        >
          <span className="text-sm font-medium">Statistik JP per Kelas</span>
          {showJPStats ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </Button>
        {showJPStats && <JPStatsBox selectedKelasId={selectedKelas || undefined} />}
      </div>

      {/* Fixed Schedule (Collapsible) */}
      {selectedKelas && (
        <div>
          <Button
            variant="outline"
            onClick={() => setShowFixedSchedule(!showFixedSchedule)}
            className="w-full justify-between mb-2"
          >
            <span className="text-sm font-medium">
              Jadwal Tetap (JP Tetap)
              {fixedSchedules.length > 0 && (
                <span className="ml-2 text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded">
                  {fixedSchedules.length}
                </span>
              )}
            </span>
            {showFixedSchedule ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </Button>
          {showFixedSchedule && (
            <FixedScheduleCard
              fixedSchedules={fixedSchedules}
              onEdit={(schedule) => {
                console.log('Edit fixed schedule:', schedule);
              }}
              onDelete={handleDeleteFixedSchedule}
              isLoading={fixedLoading}
            />
          )}
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteConfirm !== null && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-lg p-4 sm:p-6 max-w-md w-full"
          >
            <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-2">
              Konfirmasi Hapus
            </h3>
            <p className="text-sm sm:text-base text-gray-600 mb-6">
              Apakah Anda yakin ingin menghapus blok waktu ini? Semua assignment terkait juga akan
              dihapus.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-end">
              <Button
                variant="outline"
                onClick={() => setDeleteConfirm(null)}
                className="w-full sm:w-auto"
              >
                Batal
              </Button>
              <Button
                variant="destructive"
                onClick={() => handleDelete(deleteConfirm)}
                className="w-full sm:w-auto"
              >
                Hapus
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      <TimeBlockModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        timeBlock={editingBlock}
        existingBlocks={timeBlocks}
        selectedKelasId={selectedKelas || undefined}
        onSave={handleSave}
      />
    </div>
  );
}