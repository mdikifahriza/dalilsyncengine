// src/App.tsx - UPDATED: Removed RoomsPage
import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import MainLayout from './components/layout/MainLayout';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import TeachersPage from './pages/TeachersPage';
import ClassesPage from './pages/ClassesPage';
import SubjectsPage from './pages/SubjectsPage';
// ❌ REMOVED: import RoomsPage from './pages/RoomsPage';
import GeneratorPage from './pages/GeneratorPage';
import SchedulePage from './pages/SchedulePage';
import TimeBlocksPage from './pages/TimeBlocksPage';
import CurriculumPage from './pages/CurriculumPage';
import SchoolSettingsPage from './pages/SchoolSettingsPage';
import SetupWizardPage from './pages/SetupWizardPage';
import type { ViewType } from './types';

function AppContent() {
  const { user, loading } = useAuth();
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Not authenticated - show login/register
  if (!user) {
    if (authMode === 'register') {
      return <RegisterPage onNavigateToLogin={() => setAuthMode('login')} />;
    }
    return <LoginPage onNavigateToRegister={() => setAuthMode('register')} />;
  }

  // Authenticated - show main app
  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardPage />;
      case 'teachers':
        return <TeachersPage />;
      case 'time-blocks':
        return <TimeBlocksPage />;
      case 'classes':
        return <ClassesPage />;
      case 'subjects':
        return <SubjectsPage />;
      // ❌ REMOVED: case 'rooms'
      case 'generator':
        return <GeneratorPage onNavigate={setCurrentView} />;
      case 'schedule':
        return <SchedulePage />;
      case 'curriculum':
        return <CurriculumPage />;
      case 'school-settings':
        return <SchoolSettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <MainLayout currentView={currentView} onNavigate={setCurrentView}>
      {renderView()}
    </MainLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}